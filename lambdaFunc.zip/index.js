const { Pool, Client } = require('pg');

/*
let client;
if (typeof client === 'undefined'){
     console.log("hit")
    client = new Client({
    user: 'phortonssf',
    host:'ifindit.c9r4w6m26fqi.us-west-2.rds.amazonaws.com',
    database: 'dev',
    password: 'Kylos99sql',
    port: 5432
  })
  console.log(client, 'me')
  client.connect( err => {
	console.log('top')
	if (err){
		console.log(err, 'error!')
	//	callback(err)
	}
	//callback(null, 'connected')
  })
} 
*/


let x = 0;
exports.handler = function(event, context, callback) {
	//context.callbackWaitsForEmptyEventLoop = false;
	console.log("help", x )
	x++
	let pool = new Pool({
	  user: 'phortonssf',	
	  host: 'ifindit.c9r4w6m26fqi.us-west-2.rds.amazonaws.com',
	  database: 'dev',
	  password: 'Kylos99sql',
	  port: 5432
	}) 
         /*
	client.connect( err => {
		console.log("hit")
		if (err){
			callback(err)	
		}
		 callback(null, 'Connection established');
	}) */
	
	const query = {
		name: 'fetch-room',
		text: 'SELECT roomname FROM rooms WHERE roomname = $1',
		       values: ['kitchen'],
		       rowmode: 'array'
	}
	
	
	
	
	pool.query(query, (err, res) => {
		  console.log(err, res)
		  pool.end()
		  callback(null, "hit")
	})

                 /*
		(async () => {

			  const { rows } = await pool.query('SELECT * FROM rooms', [1])
			  console.log('user:', rows)

		})().catch(e => setImmediate(() => { throw e }))
*/





}
